The OpenPose documentation is available in 2 different formats, choose your preferred one!
- As a traditional website (recommended): [cmu-perceptual-computing-lab.github.io/openpose](https://cmu-perceptual-computing-lab.github.io/openpose).
- As markdown files: [github.com/CMU-Perceptual-Computing-Lab/openpose/tree/master/doc/installation](https://github.com/CMU-Perceptual-Computing-Lab/openpose/tree/master/doc/installation).
