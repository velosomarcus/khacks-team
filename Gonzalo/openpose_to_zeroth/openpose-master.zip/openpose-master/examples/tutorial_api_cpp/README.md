# C++ API Examples
See the [OpenPose C++ API doc](../../doc/04_cpp_api.md) for more details on this folder.

This folder provides examples to the basic OpenPose C++ API. The analogous Python API is exposed in [examples/tutorial_api_python/](../tutorial_api_python/).
