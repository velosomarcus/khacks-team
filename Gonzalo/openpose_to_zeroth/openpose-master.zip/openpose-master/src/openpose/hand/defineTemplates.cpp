#include <openpose/hand/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WHandDetector);
    DEFINE_TEMPLATE_DATUM(WHandDetectorFromTxt);
    DEFINE_TEMPLATE_DATUM(WHandDetectorTracking);
    DEFINE_TEMPLATE_DATUM(WHandDetectorUpdate);
    DEFINE_TEMPLATE_DATUM(WHandExtractorNet);
    DEFINE_TEMPLATE_DATUM(WHandRenderer);
}
